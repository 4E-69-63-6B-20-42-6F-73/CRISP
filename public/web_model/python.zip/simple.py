# Note: disabled tsne.py by commenting out in init.py
# And commented out sample.name

import pandas as pd
import xgboost as xgb
from sklearn.metrics.pairwise import cosine_similarity
from pickle import load

import sys
sys.path.append("./code")
from poodle import utils as pup

import pickle
def pickle_load(filepath):
    with open(filepath, 'rb') as handle:
        return pickle.load(handle)


df_meta = pickle_load("./data/meta.pickle")
original_embedding = pickle_load("./data/original_embedding.pickle")
sim_matrix = cosine_similarity(original_embedding)
columns = pickle_load("./data/columns.pickle")

# Predict a single patient.
def predict(autoencoder, data: list):
    # For now we assume this:
    patient = data[0]
    numeric = data[1:7]
    categoric = data[7:]

    d_input = columns

    result = []

    sample_cat = pd.DataFrame([categoric], columns=columns['cat'])
    sample_num = pd.DataFrame([numeric], columns=columns['num'])

    sample = pd.concat([sample_cat, sample_num], axis=0)

    result.append(pup.getOrientation(autoencoder, df_meta, original_embedding, d_input, sample, sim_matrix=sim_matrix, cluster_label='PhenoGraph_clusters'))

    archetype_columns = ['weight_pval', 'weight_mean', 'weight_sd', 'cluster_mean_pat', 'cluster_sd_pat'] # + latent factors?
    l_col = []

    for i in range(4):
        l_col.extend(['%s_%s' % (col, i) for col in archetype_columns ])

    characteristics = pd.DataFrame(result, columns=l_col)

    loaded_bst = xgb.Booster()
    loaded_bst.load_model("./labeler/xgb_model.json")

    scaler = load(open("./labeler/scaler.pkl" , 'rb'))
    return loaded_bst.predict(xgb.DMatrix(scaler.transform(characteristics)))

# data = "01001|0.3126284518385913|1.4956309894562494|0.33411334769482753|-0.2849260529871922|0.08027216901345147|-0.03340348055189329|1.0|1.0|0.0|1|0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|1.0|0.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0|1.0|1.0|0.0|1.0|0.0|1.0|0.0|1.0|0.0|0.0".split("|")
# predict({}, data)
