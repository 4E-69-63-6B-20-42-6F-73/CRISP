# Note: disabled tsne.py by commenting out in init.py

import pandas as pd
import xgboost as xgb
from sklearn.metrics.pairwise import cosine_similarity
from pickle import load

import tensorflow as tf

import sys
sys.path.append("./code")
from poodle import utils as pup

import pickle
def pickle_load(filepath):
    with open(filepath, 'rb') as handle:
        return pickle.load(handle)


df_meta = pickle_load("./data/meta.pickle")
original_embedding = pickle_load("./data/original_embedding.pickle")
sim_matrix = cosine_similarity(original_embedding)


# Load modalities from replication set
df_categoric_replication = pd.read_csv('C:\\project\\stage\\Poodle\\example_data/replication/ClusteringIMPROVED_CATEGORICAL.csv', sep='|').dropna().drop_duplicates(subset=["PATNR"])
df_numeric_replication = pd.read_csv('C:\\project\\stage\\Poodle\\example_data/replication/ClusteringIMPROVED_NUMERIC.csv', sep='|').dropna().drop_duplicates(subset=["PATNR"]) #[['Leuko', 'Hb',   'MCV', 'Trom', 'BSE',  'Age']]

overlapping = (set(df_numeric_replication['PATNR'].unique())).intersection(set(df_categoric_replication['PATNR'].unique()))

df_numeric_replication = df_numeric_replication[df_numeric_replication['PATNR'].isin(overlapping)].reset_index(drop=True)
df_categoric_replication = df_categoric_replication[df_categoric_replication['PATNR'].isin(overlapping)].reset_index(drop=True)

autoencoder = tf.saved_model.load("C:\\project\\stage\\Poodle\\example_data\\model\\replication_mmae")

def predict(autoencoder, df_categoric_replication, df_numeric_replication):
    lcat = [col for col in df_categoric_replication.columns if col not in ['PATNR']]
    lnum = [col for col in df_numeric_replication.columns if col not in ['PATNR','FirstConsult', 'patnr', 'pseudoId']]
    d_input = {'cat' : list(df_categoric_replication[lcat].columns), 'num' : list(df_numeric_replication[lnum].columns)}


    result = []
    for ix in range(len(df_categoric_replication)):
        sample_cat = df_categoric_replication[lcat].iloc[ix]
        sample_num = df_numeric_replication[lnum].iloc[ix]
        sample = pd.concat([sample_cat, sample_num], axis=0)
        
        result.append(pup.getOrientation(autoencoder, df_meta, original_embedding, d_input, sample, sim_matrix=sim_matrix, cluster_label='PhenoGraph_clusters'))

    archetype_columns = ['weight_pval', 'weight_mean', 'weight_sd', 'cluster_mean_pat', 'cluster_sd_pat'] # + latent factors?
    l_col = []

    for i in range(4):
        l_col.extend(['%s_%s' % (col, i) for col in archetype_columns ])

    characteristics = pd.DataFrame(result, columns=l_col) 

    loaded_bst = xgb.Booster()
    loaded_bst.load_model(".\\labeler\\xgb_model.json")

    scaler = load(open(".\\labeler\\scaler.pkl" , 'rb'))
    return loaded_bst.predict(xgb.DMatrix(scaler.transform(characteristics))) 


print(predict(autoencoder, df_categoric_replication, df_numeric_replication))